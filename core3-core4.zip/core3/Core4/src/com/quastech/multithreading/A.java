/**
 * 
 */
package com.quastech.multithreading;

/**
 * @author Aj
 *
 */
public class A extends Thread {

	/**
	 * 
	 */
	public A() {
		
	}
	
	//
	public void run(){
		
		//
		for (int j = 0; j < 100; j++) {
			System.out.println("A "+j);
		}
	}

}
