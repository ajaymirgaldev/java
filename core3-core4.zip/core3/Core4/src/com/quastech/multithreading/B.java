/**
 * 
 */
package com.quastech.multithreading;

/**
 * @author Aj
 *
 */
public class B extends Thread {

	/**
	 * 
	 */
	public B() {
		// 
	}

	//
	public void run(){
		
		//
		for (int j = 0; j < 100; j++) {
			System.out.println("B "+j);
		}
	}

}
