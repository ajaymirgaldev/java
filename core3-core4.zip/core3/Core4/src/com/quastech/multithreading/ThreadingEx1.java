/**
 * 
 */
package com.quastech.multithreading;

/**
 * @author Aj
 *
 */
public class ThreadingEx1 {

	/**
	 * 
	 */
	public ThreadingEx1() {
		// 
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 
		Thread t1 = new Thread(new A()); 
		
		//
		Thread t2 = new Thread(new B());
		
		//
		t1.start();
		t2.start();
	}

}
