/**
 * 
 */
package com.quastech.multithreading;

/**
 * @author student
 *
 */
public class ThreadingWithRunnable implements Runnable{

	/**
	 * 
	 */
	public ThreadingWithRunnable() {
		// 
	}
	 
	public void run() {
		
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 
		A a1 = new A();
		B b2 = new B();
		
		//
		Thread t1 = new Thread(a1);
		Thread t2 = new Thread(b2);
		
		//
		t1.start();
		t2.start();
	}

}
