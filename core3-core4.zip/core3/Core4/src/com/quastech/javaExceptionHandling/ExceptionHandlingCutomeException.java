/**
 * 
 */
package com.quastech.javaExceptionHandling;

import java.util.Scanner;

/**
 * @author Ajay Mi
 *
 */
public class ExceptionHandlingCutomeException {
	private int age = 0;
	
	Scanner scanner = new Scanner(System.in);
	/**
	 * 
	 */
	public ExceptionHandlingCutomeException() throws CustomeExceptionHandling {
		// 
		System.out.println("Please input your Age.");
		age = scanner.nextInt();
		
		//
		try{
			validateAge(age);
		}catch(Exception e){
			System.out.println(e);
		}
		
	}
	
	static void validateAge(int _age) throws CustomeExceptionHandling {
		
		//
		if(_age < 18){
			System.out.println("Your age is "+_age);
			throw new CustomeExceptionHandling("You are not qualified to Vote");
		}else{
			System.out.println("You are qualified to Vote");
		}
		
	};

	/**
	 * @param args
	 */
	public static void main(String[] args) throws CustomeExceptionHandling {
		// 
		ExceptionHandlingCutomeException ehce = new ExceptionHandlingCutomeException();
	}

}
