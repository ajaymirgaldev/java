/**
 * 
 */
package com.quastech.javaExceptionHandling;

import java.util.Scanner;

/**
 * @author student
 *
 */
public class ExceptionHandling_Inheritance_Child {

	/**
	 * 
	 */
	public ExceptionHandling_Inheritance_Child() throws CustomeExceptionHandling{
		// 
		//System.out.println("Input:");
		//boolean t = false;
		//validateExceptionHandling(t);
	}
	
	void validateExceptionHandling(boolean _flag) throws CustomeExceptionHandling {
		//
		System.out.println(_flag);
		if(_flag){
			try {
				
				//
				
				
			} catch (Exception e) {
				
				//
				System.err.println("There is an error: ");
				System.err.println(e);
			}
		}
	}
	

	/**
	 * @param args
	 */
	public static void main(String[] args) throws CustomeExceptionHandling{
		Scanner sc = new Scanner(System.in);
		
		// 
		ExceptionHandling_Inheritance_Child EHIC = new ExceptionHandling_Inheritance_Child();
		
		//
		System.out.println("Input:");
		Boolean t = sc.nextBoolean();
		
		EHIC.validateExceptionHandling(t);
		
	}

}
