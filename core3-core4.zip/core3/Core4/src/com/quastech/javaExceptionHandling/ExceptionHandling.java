/**
 * 
 */
package com.quastech.javaExceptionHandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * @author student
 *
 */
public class ExceptionHandling {
	Scanner sc = new Scanner(System.in);
	int count = 100;
	int userInput = 0;
	int total = 0;
	String a = null;
	int length = 0;
	/**
	 * @throws Exception 
	 * 
	 */
	public ExceptionHandling() throws Exception {
		
		//Try Catch //
		tryCatch();
		
		//throws
		throwsException();
		
		//throw
		throwException();
		
	}

	//Try Catch //
	void tryCatch(){
		try{
			
			//InputMismatchException
			System.out.println("Please input the Number:");
			userInput = sc.nextInt();
			
			//Arithmatical//
			System.out.println("Please input the Number:");
			userInput = sc.nextInt();
			total = count / userInput;
			
			//
			System.out.println(a.length());
			
		}
		
		//InputMismatchException
		catch(InputMismatchException e){
			System.out.println("InputMismatchException: Exception handled : ");
			System.out.println("Error : "+e);
		}
		
		//ArithmeticException
		catch(ArithmeticException e){
			System.out.println("ArithmeticException: Exception handled : ");
			System.out.println("Error : "+e);
		}
		
		//NullPointerException
		catch(NullPointerException e){
			System.out.println("NullPointerException: Exception handled : ");
			System.out.println("Error : "+e);
		}
		
		//Exception
		catch(Exception e){
			System.out.println("Error : "+e);
		}
		
		//Finally
		finally{
			System.out.println("Finally : ");
			System.out.println("This is the 'finally' default block. ");
			sc.close();
		}
		
		//
		System.out.println("Number Input: "+userInput);
	} 
	
	//throws//
	void throwsException() throws FileNotFoundException {
		FileInputStream file = new FileInputStream("/hello.xlsx");
	}
	
	//throw//
	void throwException() throws Exception {
		
		//
		System.out.println("Please input Number Lesser then 100.");
		length = sc.nextInt();
		
		if (length > 100 ) {

			try {
				throw new Exception("Throw Exception: As your input Number is not Lesser then 100.");
			} catch (Exception e) {
				System.out.println("Error "+e);
			}
		}else{
			System.out.println("Good input Number Lesser then 100.");
		}
	}
	
	
	/**
	 * @param args
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws Exception {

		// 
		ExceptionHandling tc = new ExceptionHandling();
		
		//
		//tc.throwException();
		
		System.out.println("throwException ");
	}

}
