/**
 * 
 */
package com.quastech.javaExceptionHandling;

/**
 * @author student
 *
 */
public class CustomeExceptionHandling extends Exception{

	/**
	 * 
	 */
	public CustomeExceptionHandling(String a) {
		// 
		super(a);
	}

}
