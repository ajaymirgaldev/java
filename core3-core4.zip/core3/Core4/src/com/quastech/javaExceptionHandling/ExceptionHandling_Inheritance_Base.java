/**
 * 
 */
package com.quastech.javaExceptionHandling;

/**
 * @author Ajay Mi
 *
 */
public class ExceptionHandling_Inheritance_Base {

	/**
	 * 
	 */
	public ExceptionHandling_Inheritance_Base(){}
	
	//
	void validateExceptionHandling(boolean _flag) throws CustomeExceptionHandling{
		
		//
		if(_flag){
			try {
				
				//
				
				
			} catch (Exception e) {
				
				//
				System.err.println("There is an error: ");
				System.err.println(e);
			}
		}
	} 

}
