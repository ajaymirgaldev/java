/**
 * 
 */
package j_abstract;

/**
 * @author student
 *
 */
public class Hello extends HelloAbstract {
	
	//implementation of abstract method//
	public String welcomeToAbstraction(){
		return hello;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 
		Hello he = new Hello();
		
		//
		he.hello();
		
		//
		System.out.println(he.welcomeToAbstraction());
		
		//
		String srt = "aa bbb ccc ddd";
		String t[] = {};
		srt = srt.toUpperCase();
		int index = 0;
		System.out.println(srt.split(" ")[0]);
		
		for (int i = 0; i < t.length; i++) {
			t[index] = srt.split(" ")[i];
		}
		
		System.out.println(t);
	}

}
