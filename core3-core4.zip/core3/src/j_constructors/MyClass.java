/**
 * 
 */
package j_constructors;

/**
 * @author student
 *
 */
public class MyClass {

	/**
	 * @param args
	 */
	private int a;
	private int b;
	
	//Default constructors//
	MyClass(){
		System.out.println("a = "+this.a+", b = "+this.b);
	};
	
	//------------Polymorphism//
	//
	MyClass(int _a){
		this.a = _a;
		System.out.println("a = "+this.a+", b = "+this.b);
	};
	
	//
	MyClass(int _a, int _b){
		this.a = _a;
		this.b = _b;
		System.out.println("a = "+this.a+", b = "+this.b);
	};

	
	//Copy constructor
	MyClass(MyClass ms){
		this.b = ms.a;
		this.a = ms.b;
		
		System.out.println("a = "+this.a+", b = "+this.b);
	};
	
	
	public static void main(String[] args) {
		// 
		System.out.println("--------------------ms");
		MyClass ms = new MyClass();
		
		//
		System.out.println("--------------------ms2");
		MyClass ms2 = new MyClass(10);
		
		//
		System.out.println("--------------------ms3");
		MyClass ms3 = new MyClass(10, 20);
		
		//
		System.out.println("--------------------ms4");
		MyClass ms4 = new MyClass(ms3);
		
		//
		System.out.println("--------------------ms5");
		MyClass ms5 = new MyClass(ms2);
		
		//
		System.out.println("--------------------ms6");
		MyClass ms6 = new MyClass(20, 10);
	}

}
