/**
 * 
 */
package j_static;

/**
 * @author student
 *
 */
public class MyStaticClass {

	/**
	 * @param args
	 */
	/*Declaration*/
	static String staticData = "This is static type Data"; 
	public String nonStaticData = "This is non-static type Data";
	
	//
	static int a = 0;
	static int b = 0;
	int c = 0;

	/*Implementation*/
	
	//static method//
	static void helloStatic(){
		System.out.println(staticData);
	}
	
	public void welcome(){
		System.out.println("Rule 1: Non static method can access 'static data '"+staticData);
		System.out.println("Rule 2: Non static method can access 'Non static data '"+nonStaticData);
	}
	
	public int getA(){
		return a;
	}
	
	static int get_A(){
		return a;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyStaticClass ms1 = new MyStaticClass();
		MyStaticClass ms2 = new MyStaticClass();
		MyStaticClass ms3 = new MyStaticClass();

		//access static methods on class//
		MyStaticClass.helloStatic();

		//access non-static methods on class object
		ms1.welcome();
				
		//
		System.out.println();
		System.out.println("------ class ms1");
		ms1.a = 10;
		System.out.println("a = "+ms1.getA());
		
		//
		System.out.println("------ class ms2");
		ms2.a = 20;
		System.out.println("a = "+ms2.getA());
		
		//
		System.out.println("------ class ms3");
		ms3.a = 30;
		System.out.println("a = "+ms3.getA());
		
		//
		System.out.println("------ static");
		System.out.println("a = "+MyStaticClass.get_A());
	}

}
