/**
 * 
 */
package j_hybridinharitance;

/**
 * @author student
 *
 */
public interface IAdmin extends IStudent {
	double rsfees = 2000;
	String cod = "New Rules";
	
	//
	public double fees();
	
	//
	public String codeOfConduct();
	
}
