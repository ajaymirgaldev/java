/**
 * 
 */
package j_hybridinharitance;

/**
 * @author 
 *
 */
public interface IStudent {
	String s_name = "ABC";
	String s_surname = "XYZ";
	double rollnumber = 11500458;
	
	//
	public String studentName();
	
	//
	public String studentsurname();
	
	//
	public double studentRollnumber();
	

}
