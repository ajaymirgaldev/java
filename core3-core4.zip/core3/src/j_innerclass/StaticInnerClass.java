/**
 * 
 */
package j_innerclass;

/**
 * @author student
 *
 */
public class StaticInnerClass {

	/**
	 * @param args
	 */
	static int a = 0;
	
	//
	public void outerClassMethod(){
		System.out.println("Outer Class Method");
	}
	
	//
	public void accept(){
		a = 10;
		System.out.println("outer accept Method: ");
	}
	
	//
	public void display(){
		System.out.println("outer display Method: " + a);
	}
	
	//static inner class
	public static class MyClass {
		static int b = 0;
		
		//
		public void innerClassMethod(){
			System.out.println("inner Class Method");
		}
		
		//
		public void accept(){
			b = 20;
			System.out.println("inner accept Method: ");
		}
		
		//
		public void display(){
			System.out.println("inner display Method: "+b);
		}
	}
	
	public static void main(String[] args) {
		
		//outer class instance//
		StaticInnerClass outer = new StaticInnerClass();
		
		//
		outer.accept();
		outer.display();
		
		//inner class instance//
		StaticInnerClass.MyClass inner = new StaticInnerClass.MyClass();
		
		//
		inner.accept();
		inner.display();
		
		//
		System.out.println(StaticInnerClass.MyClass.b);
		
	}

}
