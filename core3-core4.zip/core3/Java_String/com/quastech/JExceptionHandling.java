/**
 * 
 */
package com.quastech;

import java.util.Scanner;

/**
 * @author student
 *
 */
public class JExceptionHandling {
	private int a = 10;
	private int b = 0;
	private int c = 0;
	Scanner scanner = new Scanner(System.in);
	/**
	 * 
	 */
	public JExceptionHandling() {
		
	}
	
	//
	private int division(int a, int b){
		this.a = a; 
		this.b = b;
		
		//
		try{
			
			//
			this.c = this.a / this.b; 
			return this.c;
			
		}catch(Exception error){
			System.err.println("Denomiter should not be 0");
			System.err.println(error);
		}
		
		System.out.println();
		return 0;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//
		JExceptionHandling eh = new JExceptionHandling();
		
		//
		System.out.print("Please input value of a = ");
		int a = eh.scanner.nextInt();
		
		//
		System.out.print("Please input value of b = ");
		int b = eh.scanner.nextInt();
		
		//
		int c = eh.division(a, b);
		System.out.println();
		System.out.println("Answer: "+c);
		
	}

}
