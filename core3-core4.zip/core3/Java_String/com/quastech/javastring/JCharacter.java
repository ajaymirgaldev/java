/**
 * 
 */
package com.quastech.javastring;

/**
 * @author Ajay_Mi
 *
 */
public class JCharacter {

	/**
	 * 
	
	public JCharacter() {
		// 
	} */

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String a = "A";
		
		// 
		Character c = new Character('A');
		Character c1[] = new Character[10];
		String a1 = "hello quastech";
		String a2 = "";
		//
		System.out.println(Character.compare('A', 'B'));
		int t = Character.compare('A', 'A');
		
		
		//
		if (t < 0)  {
			System.out.println("Is not equal");
		}else{
			System.out.println("Is equal");
		}
		
		System.out.println();
		//
		for (int i = 0; i < a1.split(" ").length; i++) {
			
			char t1 = a1.split(" ")[i].charAt(0);//a1.split(" ")[i];
			System.out.println();
			
			//String t2 = t1.charAt(0);
			//t1.replace(t2, t2.toUpperCase());
			//a2 += t1+" ";
		}
		
		System.out.println(a2);
		
	}
	
	
}
