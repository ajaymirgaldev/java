/**
 * 
 */
/**
 * @author student
 *
 */
package com.quastech.javastring;