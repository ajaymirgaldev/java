/**
 * 
 */
package com.org.j_string;

/**
 * @author student
 *
 */
public class String_Buffer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Using StringBuffer class
		String a = "Hello";
		//Constructor without param // 
		StringBuffer myStrBuffer = new StringBuffer();
		
		//Constructor with param // 
		StringBuffer myStrBuffer2 = new StringBuffer("A");
		
		//Constructor with param as variable // 
		StringBuffer myStrBuffer3 = new StringBuffer(a);
		
		//Constructor with param as variable // 
		StringBuffer myStrBuffer4 = new StringBuffer();
		
		//-----------------------
		
		//StringBuffer capacity retrun default capacity which is 16
		myStrBuffer.capacity();
		System.out.println("StringBuffer capacity retrun default capacity which is "+myStrBuffer.capacity());
		
		//capacity()//
		//myStrBuffer.capacity();	
		//System.out.println("StringBuffer capacity retrun default capacity which is "+myStrBuffer.capacity());
		
		//append()//
		myStrBuffer.append(a);
		System.out.println("StringBuffer append will append value at the of the string '"+myStrBuffer+"' capacity: "+myStrBuffer.capacity());
		
		//length()//
		myStrBuffer.length();
		System.out.println("StringBuffer length() method will return length of the of the string: "+myStrBuffer.length());
		
		//SetLength()//
		//myStrBuffer.setLength(20);
		System.out.println("StringBuffer setLength(n) method will restrict to max lenght: "+myStrBuffer.length());
		
		//reverse()
		myStrBuffer.reverse();
		System.out.println("StringBuffer reverse() method will reverse string value: "+myStrBuffer+"'");
		myStrBuffer.reverse();
		
		//equals(arg);		
		myStrBuffer.equals(a);
		System.out.println(myStrBuffer.capacity());
		System.out.println(myStrBuffer3.capacity());
		
		System.out.println("StringBuffer equals(arg) method will comapre two values "+myStrBuffer.equals(myStrBuffer3));
		
		
	}

}
