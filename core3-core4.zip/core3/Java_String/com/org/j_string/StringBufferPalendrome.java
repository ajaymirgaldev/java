/**
 * 
 */
package com.org.j_string;

/**
 * @author student
 *
 */
public class StringBufferPalendrome {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//
		System.out.println("String Buffer Palendrome");
		
		String s1 = new String("02022020");
		String s2 = new String();
		StringBuffer sb1 = new StringBuffer("02022020");
		
		//revere sb1//
		sb1.reverse();System.out.println(sb1);
		
		//
		s2 = sb1.toString();
		
		if (s1.equals(s2)) {
			System.out.println("is a palidrom number");
		}else {
			System.out.println("is not a palidrom number");
		}
		
	}

}
