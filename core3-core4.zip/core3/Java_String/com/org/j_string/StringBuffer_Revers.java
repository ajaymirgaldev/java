package com.org.j_string;

public class StringBuffer_Revers {

	public static void main(String[] args) {
		// StringBuffer Revers using custome function
		
		String a = new String("Quastech");
		char ch[] = a.toCharArray();
		char temp;
		String b = "";
		
		System.out.println("String: "+a);
		
		//
		for (int i = 0; i < ch.length/2; i++) {
			//System.out.println(c[i]);
			temp = ch[i];
			ch[i] = ch[ch.length -i -1];
			ch[ch.length -i -1] = temp;
		}
		
		//
		for (char c : ch) {
			b += c;
		}
		
		System.out.println("Revers "+b);
		
		//===================
		StringBuffer a1 = new StringBuffer("A");
		StringBuffer b2 = new StringBuffer("A");
		
		//
		System.out.println(a1.equals(b2));
		
		/*if(a1.equals(b1)){
			
		}*/
	}

}
