/**
 * 
 */
package com.org.j_string;

/**
 * @author Ajay Mi
 *
 */
public class CharactorClass {

	/**
	 * 
	 */
	public CharactorClass() {
		
		//
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//

	}

}
