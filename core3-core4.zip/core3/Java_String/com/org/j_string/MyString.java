/**
 * 
 */
package com.org.j_string;

/**
 * @author student
 *
 */
public class MyString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// compare and sort Array of String...
		
		String s[] = {"shrikant", "joseph", "naresh","jaseph","noresh","jaaseph"};
		String temp;
		
		for(int i=0; i<s.length; i++){
			//i = first word//
			
			for(int j=i+1; j<s.length; j++){
				
				//j = 2nd word//
						
				//compare first word caharactors with second word charactors//
				for(int p=0; p<s[j].length(); p++){
					
					//a = first-word[p] character//
					int a = s[i].charAt(p);
					
					//b = second-word[p] character//
					int b = s[j].charAt(p);
					
					//compare first-word[p] char with second-word[p]//
					if (a<b) {
						
						//if first-word[p] is smaller then the second-word[p]
						//loop will break
						break;
					}else if( a>b ) {
					
						//if first-word[p] is greater then the second-word[p]
						
						//
						temp = s[i]; // first-word
						s[i] = s[j]; // second-word
						
						//
						s[j] = temp; //second-word swiped with first-word in "s" array// 
						
						//
						break;
					}else if (a==b) {
						//if first-word[p] is equal then the second-word[p]
						//loop will continue
						continue;
					}
				}
				
			}
		}
		
		//
		for (String r:s) {
			System.out.println(r);
		}
	}

}
