package day8;

import java.util.Scanner;

//Method With / Without Parameter
//Method With / Without with or without return type//
public class TypesOfMethods {
	//
	Scanner sc = new Scanner(System.in);
	
	// 
	int a, b, f, i, l, sum;
	
	//Method With Parameter
	public void factorialWithParam(int a){
		
		sum = 0;

		//
		for (int i = 0; i <= a; i++) {
			sum = a * i;
		}
		
		System.out.println("factorial of "+a + " is "+sum);
	}
	
	//Method Without Parameter
	public void factorialWithoutParam(){
		
		sum = 0;
		
		//Factorial Without Parameter
		System.out.println("\n-------------------- Factorial Without Param\nPlease input number");
		a = sc.nextInt();
		
		//
		for (int i = 0; i <= a; i++) {
			sum = a * i;
		
		}
		
		System.out.println("factorial of "+a + " is "+sum);
		
	}
	
	//with Parameter - no return
	public void add(int a, int b){
		System.out.println("\n--------------------Add Without Param\nPlease input number");
		
		sum = 0;
		
		//
		sum = a + b;
		
		//
		System.out.println("Sum "+sum);
		
	}
	
	//with Parameter - no return value
	public int multi(){
		System.out.println("\n--------------------Multiplication Without Param\n");
		//
		System.out.println("Multiplication \nPlease input number");
		int a = sc.nextInt();
		
		System.out.println("Multiplication \nPlease input number");
		int b = sc.nextInt();
		
		sum = 0;
		
		//
		sum = a * b;
		
		//
		return sum;
		
	}
	
	//with Parameter - with return value
	public int subtraction(int a, int b){
		sum = 0;
		
		//
		sum = a - b;
		
		//
		return sum;
	}
	
	public static void main(String[] args) {
		// 
		TypesOfMethods f = new TypesOfMethods();
		
		//
		System.out.println("Factorial With Param\nPlease input number");
		int a1 = f.sc.nextInt();
		f.factorialWithParam(a1);
		
		//
		f.factorialWithoutParam();
		
		//
		System.out.println("\n--------------------Add With Param\nPlease input number");
		int a = f.sc.nextInt();
		System.out.println("Please input number");
		int b = f.sc.nextInt();
		f.add(a , b);
		
		//
		int t = f.multi(); 
		System.out.println("Multiplication "+t);
		
		//
		//
		System.out.println("\n--------------------Subtraction With Param\nPlease input number");
		a = f.sc.nextInt();
		
		System.out.println("Please input number");
		b = f.sc.nextInt();
		
		t = f.subtraction(a, b);
		System.out.println("Subtraction "+t);
	}

}
