package day8;

import java.util.Scanner;

public class TypesOfMethods2 {
	Scanner sc = new Scanner(System.in);
	
	//Declaration//
	
	
	//initialization //
	int a = 0; int n = 0; int rem = 0; int rev = 0;
			
	//Swiping values with params with no return value//
	public void swipingW(int a, int b){
		
		System.out.println("Swiping inputs : "+a + " "+b);
		
		int t = a;
		a = b;
		b = t;
		
		//
		System.out.println("a: "+a+" b: "+b);
	}
	
	
	//Swiping Without params
	public void swipingWI(){
		
		System.out.println("Swiping inputs : 1");
		int a = sc.nextInt();
		
		System.out.println("Swiping inputs : 2");
		int b = sc.nextInt();
		
		System.out.println("Swiping inputs : "+a + " "+b);
		
		int t = a;
		a = b;
		b = t;
		
		//
		System.out.println("a: "+a+" b: "+b);
	}
	
	//Reveres With parameters
	public int reversW(int a){
		int n = 0;
		n = a;
		
		//
		while(n > 0){
			
			//reminder//
			rem = n % 10;
			
			//
			rev = rev * 10 + rem;
			System.out.println(rev);
			//
			n = n / 10;
		}
		
		return rev;
	}
	
	//Reveres Without parameters
	public void reversWI(){
		System.out.println("Inputs : ");
		rem = 0;
		rev = 0;
		int n = sc.nextInt();
		
		//
		while(n > 0){
			
			//reminder//
			rem = n % 10;
			
			//
			rev = rev * 10 + rem;
			System.out.println(rev);
			//
			n = n / 10;
		}
		
		//
		System.out.println("Revers  : "+rev);
	}
	
	
	//
	public static void main(String[] args) {
		//
		TypesOfMethods2 t = new TypesOfMethods2();
		System.out.println("-------------swiping W params------------------");
		
		//
		/*System.out.println("Swiping inputs : 1");
		int a = t.sc.nextInt();
		
		System.out.println("Swiping inputs : 2");
		int b = t.sc.nextInt();
		t.swipingW(a, b);

		//
		System.out.println("---------swiping WO params----------------------");
		t.swipingWI();*/
		
		//
		System.out.println("---------swiping w params----------------------");
		//
		System.out.println("Inputs : ");
		int a = t.sc.nextInt();
		System.out.println("Revers  : "+t.reversW(a));
		
		//
		System.out.println("---------swiping WI params----------------------");
		t.reversWI();
	}
	

}
