package j_polymorphism;

import java.util.Scanner;

public class CalculateArea extends Overloading {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int h, w, r, menuChoice;
		double hd, wd;
	
		//
		CalculateArea cal = new CalculateArea();
		
		String loop = "Y";
		do{
			
			//
			System.out.println("Menu:");
			System.out.println(" 1. Square\n 2. Rectangle\n 3. Circle\n 4. Tangle");
			menuChoice = scanner.nextInt();
			//
			switch(menuChoice){
			case 1:
				//Area of Square//
				cal.area();
				break;
				
			case 2:
				//Area of Rectangle
				System.out.println("--------------------------------");
				System.out.println("Please provide Rectangle height ");
				h = scanner.nextInt();
				
				System.out.println("Please provide Rectangle width ");
				w = scanner.nextInt();
				cal.area(h, w);
				break;
				
			case 3:
				//Area of Circle//
				System.out.println("--------------------------------");
				System.out.println("Please provide Circle Redius ");
				r = scanner.nextInt();
				cal.area(r);
				break;
				
			case 4:
				//Area of Tangle//
				System.out.println("--------------------------------");
				System.out.println("Please provide Tangle height in Double ");
				hd = scanner.nextDouble();
				System.out.println("Please provide Tangle in Double ");
				wd = scanner.nextDouble();
				cal.area(hd, wd);
				break;
			default:
				System.out.println("Input did not match.");
				//System.exit(0);
			}
			
			//	
			System.out.println("--------------------------------");
			System.out.println("Do you want to continue Y/N");
			loop = scanner.next();
			loop = loop.toLowerCase();
			
			if(loop.equals("y")){
			}else{
				System.out.println("Thanks for visit!");
				System.exit(0);
			}
			
		}while(loop.equals("y"));
	}

}
