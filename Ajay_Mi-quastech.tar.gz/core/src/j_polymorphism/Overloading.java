package j_polymorphism;

import java.util.Scanner;

public class Overloading {
	Scanner scanner = new Scanner(System.in);
	
	//
	int h;
	
	//Area method with no parameters //
	public void area(){
		System.out.println("Area of Square");
		
		System.out.println("Please input height ");
		h = scanner.nextInt();
		
		//
		System.out.println("Area of Square = "+h * h);
	}
	
	//Area method with parameters //
	public void area(int h, int w){
		System.out.println("Area of Rectangle");
		
		//
		System.out.println("Area of Rectangle = "+h * w);
	}
	
	//Area method with parameters //
	public void area(int r){
		System.out.println("Area of Circle");
		
		//
		System.out.println("Area of Circle = "+(3.14) * r);
		
	}
	
	//Area method with parameters //
	public void area(double b, double h){
		System.out.println("Area of Trangle");
		
		//
		double t = (0.5) * (b * h);
		System.out.println("Area of Trangle = "+t);
		
	}
}
