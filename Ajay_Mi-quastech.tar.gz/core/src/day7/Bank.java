package day7;

import java.util.Scanner;

public class Bank {
	// Bank Class //
	
	//Welcome msg//
	//Open Account
	//Display Account Details
	//Display Account Balance
	//Update Balance
		//Deposit
		//Withdraw

	//Display Account Details

	
	/*Declaration*/
	String ach_name, ach_address;
	long ach_contact,
	ach_initAmount = 0;
	long acc_balence = 0;
	boolean acc_status = true;

	//
	Scanner scanner = new Scanner(System.in);

	/*Implementation*/
	int ac_numbers[] = {1234567890, 1234567892, 1234567893};
	
	//
	void Bank(){
		
		//
		welcome();
		
		//
		openAccount();
	}
			
	//Welcome Method//
	void welcome(){
		System.out.println("Welcome to the SBI.");
	}
	
	//Open Account//
	void openAccount(){
		System.out.println("Please Provide Your Account Profile Details:");
		
		System.out.println("Please Provide Your Name");
		ach_name = scanner.next();
		
		//
		System.out.println("Please Provide Your Contact Number");
		ach_contact = scanner.nextInt();
		
		//
		System.out.println("Please Provide Your Address");
		ach_address = scanner.next();
		
		//
		System.out.println("Please Provide Your Initial Deposit Amount.");
		acc_balence = scanner.nextInt();
			
		//
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("Thank you! Your Account Has been Opened");
		
	}
	
	//
	void getAccountDetails(){
		
		//Name
		System.out.println("Your Name "+ach_name);
		
		//Account Number
		System.out.println("Your Account Number "+ac_numbers[0]);
		
		//Contact Number
		System.out.println("Your Contact Number "+ach_contact);
		
		//Account Address
		System.out.println("Your Address "+ach_address);
		
	}
	
	//
	void getAccountBalance(){
		System.out.println("Your Account Number "+acc_balence);
	}
	
	//
	void depositAmount(){
		System.out.println("Please input Amount ");
		acc_balence = acc_balence + scanner.nextInt();
		
		//
		//System.out.println("Your Account Balance is "+acc_balence);
		getAccountBalance();
	}
	
	//
	void withdrawAmount(){
		System.out.println("Please input Amount ");
		int t = scanner.nextInt();
		
		if(t > acc_balence){
			
			System.out.println("You dont have balance. Your Account Balance is "+acc_balence);
			
			System.out.println("Please input smaller amount ");
			t = scanner.nextInt();
			
		}else{
			acc_balence = acc_balence - t;
			System.out.println("Please Collect your cash... "+t);
		}
		
		//System.out.println("Your New Account Balance is "+acc_balence);
		getAccountBalance();
	}
	
	void exitSystem(){
		System.out.println("Thanks for Banking with us.");
		System.exit(0);
	}
	
	
	public static void main(String[] args) {
		
		//
		Bank bank = new Bank();
		System.out.println();
		System.out.println("--------------------------------");
		//
		bank.Bank();
		
		//
		bank.getAccountDetails();
		
		//
		int procceed = 0;
		int userChoice = 0;
		
		System.out.println();
		System.out.println("--------------------------------");
		//
		do{
			//Menu//
			System.out.println("Menu:");
			System.out.println("Please press 1 to Display Details");
			System.out.println("Please press 2 to Display Account Balance");
			System.out.println("Please press 3 to Deposit in Account");
			System.out.println("Please press 4 to Withdraw in Account");
			System.out.println("Please press 5 to Edit Account Profile");
			System.out.println("Please press 6 to Deactivate Accoount");
			
			//
			userChoice = bank.scanner.nextInt();
			
			//
			switch(userChoice){
				case 1:
					bank.getAccountDetails();
					break;
					
				case 2:
					bank.getAccountBalance();
					break;
					
				case 3:
					bank.depositAmount();
					break;
					
				case 4:
					bank.withdrawAmount();
					break;
					
				case 5:
					bank.openAccount();
					break;
					
				default: 
					bank.exitSystem();
			}
			
			//
			System.out.println("Do you want to continue.... Y/N");
			procceed = bank.scanner.nextInt();
			
			
		}while(procceed == 1);
		
		
		//
		bank.scanner.close();
		
		//
		bank.exitSystem();
	}

}
