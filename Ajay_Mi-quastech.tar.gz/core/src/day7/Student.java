package day7;

import java.util.Scanner;

public class Student {

	// Employee class //
	
	/*Declaration*/
	String s_name;
	int s_id, s_sum, s_marks[] = new int[3];
	float s_percentages;
	long s_contact;
	String s_grade;
	
	//
	Scanner scanner = new Scanner(System.in);

	/*Implementation*/
	

	//
	Student(){};
	
	//Get employee details //
	public void setStudentDetails(){
		
		//Student Name
		System.out.print("Please input Student Name ");
		s_name = scanner.next();
		
		//Student id
		System.out.print("Please input Student ID ");
		s_id = scanner.nextInt();
		
		//Student Contact //
		System.out.print("Please input Student Contact ");
		s_contact = scanner.nextInt();
		
		
		//Student marks
		for (int i = 0; i < s_marks.length; i++) {
			System.out.print("Please input Student marks for subject "+(i+1)+": ");
			s_marks[i] = scanner.nextInt();
			s_sum = s_sum + s_marks[i];
		}
		
		//Student Percentage
		s_percentages = ( s_sum / (s_marks.length ) ) ;
		
		//
		if(Math.round(s_percentages) >= 75){
			//System.out.println("Distingstion " );
			s_grade = "Distingstion ";
		}
		else if (((Math.round(s_percentages) >60) && Math.round(s_percentages) <75)){
			//System.out.println("1st Class" );
			s_grade = "1st Class ";
		}
		else if((Math.round(s_percentages) >35) && Math.round(s_percentages) <=60){
			//System.out.println("2st Class" );
			s_grade = "2st Class ";
		}
		else {
			//System.out.println("fail" );
			s_grade = "Fail ";
		}
		
	}
	
	//fetch employee details
	void getStudentDetails(){

		//Student Name //
		System.out.println("Student Name: "+s_name);
		
		//Student ID //
		System.out.println("Student ID: "+s_id);
		
		//Contact
		System.out.println("Student Contact: "+s_contact);

	}
	
	//Get Marks //
	void getStudentMarks(){

		for (int i = 0; i < s_marks.length; i++) {
			System.out.println("Student Subject "+(i+1)+" marks: "+s_marks[i]);
		}
	}
	
	//Student Percentage
	void getStudentPercentage(){
		System.out.println("Student Percentage: "+Math.round(s_percentages)+"%");
	}
	
	//Student Grade
	void getStudentGrade(){
		System.out.println("Student Grade "+s_grade);
		
	}
	
	//
	public static void main(String[] args) {
		
		//
		Student student[] = new Student[5];
		
		//
		System.out.println("Student ");
		
		int i = 0;
		do{
			//Instance//
			student[i] = new Student();
			

			//set Student details
			student[i].setStudentDetails();
			
			
			//
			i++;
		}
		while(i < student.length);
		
		////display Student details//
		System.out.println(" -----Output ------- ");
		for (int j = 0; j < student.length; j++) {
			
			System.out.println(" -----Details of the Student"+(j+1)+"  ------- ");
			
			//
			student[j].getStudentDetails();
			
			//
			student[j].getStudentMarks();
			
			//
			student[j].getStudentPercentage();
			
			//
			student[j].getStudentGrade();
		}
		
	}

}
