package day7;
import java.util.Scanner;

//Java Setters Getters//
public class SettersGettersStudent {
	
	/*Declaration*/
	private String s_name;
	private int s_id;
	private long s_contact;

	//
	Scanner scanner= new Scanner(System.in);

	/*Implementation*/


	//Constructors //
	void SettersGettersStudent(){
		System.out.println("Welcome to Encapsulations!");
	}
	
	//setter function for student name
	public void setStudentName(String _name){
		s_name = _name;
	}
	
	//getter function for student name
	public String getStudentName(){
		return s_name;
	}
	
	//setter function for student ID
	public void setStudentID(int _id){
		s_id = _id;
	}
	
	//getter function for student ID
	public int getStudentID(){
		return s_id;
	}
	
	//setter function for student Contact
	public void setStudentContact(long _contact){
		s_contact = _contact;
	}
	
	//getter function for student Contact
	public long getStudentContact(){
		return s_contact;
	}
	
	//
	public static void main(String[] args) {
		
		// 
		SettersGettersStudent student = new SettersGettersStudent();
		
		//
		student.SettersGettersStudent();
		System.out.println();
		
		//set Student Name
		System.out.println("Please input Student Name:");
		String _name = student.scanner.next();
		student.setStudentName(_name);
		
		//set Student ID
		System.out.println("Please input Student ID:");
		int _id = student.scanner.nextInt();
		student.setStudentID(_id);
		
		
		//set Student Contact
		System.out.println("Please input Student Contact:");
		long _contact = student.scanner.nextLong();
		student.setStudentContact(_contact);
		
		System.out.println("-------------------Output");
		System.out.println("Student Name :"+student.getStudentName());
		System.out.println("Student ID :"+student.getStudentID());
		System.out.println("Student Contact:"+student.getStudentContact());
		
	}

}
