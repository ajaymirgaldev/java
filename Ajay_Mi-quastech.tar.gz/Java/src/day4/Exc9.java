package day4;

import java.util.Scanner;


public class Exc9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		*
		**
		***
		****
		*/
		
		// 
		int i, j, n, c;
		
		//
		i = j = 1; 
		c = n = 4;
		
		//
		for (i = 1; i<=n; i++){
			
			for (j = 1; j<=i; j++){
				System.out.print("*");
			}
			
			//
			System.out.println();
		}
		
		//

		//
		for (i = 3; i<=n; i++){
			
			for (j = 1; j<=c; j++){
				System.out.print("*");
			}
			c--;
			//
			System.out.println();
		}

	}

}
