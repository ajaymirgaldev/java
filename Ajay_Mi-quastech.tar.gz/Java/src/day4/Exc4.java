package day4;

import java.util.Scanner;

public class Exc4 {

	public static void main(String[] args) {
		
		//Q. Reveres the input number//
		
		//Declaration//
		int a, n, rem, rev;
		
		//initialization //
		a = n =  rem = rev = 0;
		
		//
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		a = n;
		
		//
		while(n > 0){
			
			//reminder//
			rem = n % 10;
			
			//
			rev = rev * 10 + rem;
			
			//
			n = n / 10;
		}
			
		System.out.println("rev " + rev);
		
		//
		if(a == rev){
			System.out.println(a + " is paledrom number.");	
		}else{
			System.out.println(a + " is not paledrom number.");
		}
		
		sc.close();

	}

}
