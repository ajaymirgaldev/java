package day4;

public class Exercise1 {

	public static void main(String[] args) {
				
		//sum = x + x2/2 + x3/3 + x3/3 + x4/4;
		
		
		//Declaration 
		int i, x, sum;
		
		//initialization //
		i = 1;
		x = 10;
		sum = 0;
		
		for (i = 1; i< x; i++){
			System.out.print(x/i);
			System.out.print(",");
			sum = sum + (x/i);
		}
		
		//
		System.out.println("sum "+ sum);

	}

}
