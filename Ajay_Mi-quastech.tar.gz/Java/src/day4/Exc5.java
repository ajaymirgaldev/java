package day4;

import java.util.Scanner;

public class Exc5 {

	public static void main(String[] args) {
		//Q. Find the length of the given number and sum of digits //
		
		//Declaration//
		int a, n, c, r, s;
		
		//initialization //
		a = n = c = r = s = 0;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please input your number.");	
		n = sc.nextInt();
		a = n;
		
		//get length
		while (n > 0){
			
			//
			n = n / 10;

			//
			c++;
		}
		
		System.out.println("Length "+c);	
		
		//Get su, of digits
		while (a > 0){
			//
			r = a % 10;
			s = s + r;
			//
			a = a / 10;

		}
		System.out.println("sum "+s);
		//
		sc.close();
	}

}
