package day4;

import java.util.Scanner;

public class Exc7 {

	public static void main(String[] args) {
		// do.... while loop //
		//Q. Calculator using loop //
		//Q. Sum of factors / factorial of the given number and sum 
		Scanner sc = new Scanner(System.in);
		
		//Declaration
		int i, a, b, c, n, n1;
		
		//Initialization
		i = a = b = c = n = n1= 0;
		n = 1;
		//
		i = 1;
		
		do{
			
			System.out.println("To input Symbol + use 1");
			System.out.println("To input Symbol - use 2");
			System.out.println("To input Symbol * use 3");
			System.out.println("To input Symbol / use 4");
			
			System.out.println("Please input Symbol number");
			c = sc.nextInt();
			
			if(c < 1 || c > 4){
				System.out.println( " Invalid Symbol input, programme exit");
				System.out.println("Please input Symbol number");
				c = sc.nextInt();
			}
			
			System.out.println("Please input the value 1 ");
			a = sc.nextInt();
			
			//
			System.out.println("Please input second number");
			b = sc.nextInt();
			
			//
			switch(c){
			
				//
				case 1: System.out.println((a +" + "+b)+" Answer "+ (a + b));
					break;
				//
				case 2:System.out.println((a +" - "+b)+" Answer "+ (a - b));
					break;
				
				//
				case 3: System.out.println((a +" * "+b)+" Answer "+ (a * b));
					break;
				
				//
				case 4: System.out.println((a +" / "+b)+" Answer "+ (a / b));
					break; 
				
				
				default: System.out.println( " Invalid Symbol input");
			}
			
			System.out.println("Do you want to continue Press 1 to Yes 0 Exit");
			n1 = sc.nextInt();
			
			if(n1 == 1){
				i++;
				n++;
			}else{
				System.out.println( "Programme exit");
				System.exit(0);	
			}
			
			//
			System.out.println( "Next "+n);
		}
		while(i <= n);
		sc.close();
	}

}
