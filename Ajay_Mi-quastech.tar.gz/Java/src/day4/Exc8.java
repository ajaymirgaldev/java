package day4;
import java.util.Scanner;

public class Exc8 {

	public static void main(String[] args) {
		// Q. nested loops
		
		int i, j, n;
		
		//
		i = j = 1; 
		n = 4;
		
		//
		Scanner sc = new Scanner(System.in);
		System.out.println("Please input number");
		n = sc.nextInt();
		
		//
		for (i = 1; i<=n; i++){
			for (j = 1; j<=n; j++){
				System.out.print("*");
			}
			System.out.println("");
		}
	}
}
