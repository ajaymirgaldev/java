package day4;

public class Exercise2 {

	public static void main(String[] args) {
		//sum = x + x2/2! + x3/3! + x3/3! + x4/4!;
		
		//Declaration
		int i, x, f, count;
		double s;
		
		//initialization
		i =1;
		f = 1;
		s = 0;
		x = 1;
		count = 4;
		
		//
		for(i =1; i<= count; i++){
			
			//factor ;
			f = f * i;
			
			//
			s = s + (Math.pow(x, i) / f);
			
		}
		
		//
		System.out.print("sum "+s);

	}

}
