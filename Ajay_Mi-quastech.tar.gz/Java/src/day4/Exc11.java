package day4;
public class Exc11 {

	public static void main(String[] args) {
		// 
			int i, j, n, c;
			//
			i = j = 1; 
			n = 4;
			
			
			//
			c = 3;
			for (i = 1; i<=n; i++){
				
				//
				for (j = 1; j<=n-i; j++){
					System.out.print(" ");
				}
				
				//
				for (j = 1; j<=i; j++){
					System.out.print("*");
				}
				
				//
				System.out.println();
			}
			
			//
			System.out.println();
			
			//
			c = n;
			for (i = 1; i<=n; i++){
				
				//
				for (j = 1; j<i; j++){
					System.out.print(" ");
				}
				
				//
				for (j = 1; j<=c; j++){
					System.out.print("*");
				}
				c--;
				
				//
				System.out.println();
			}
			
			//
			System.out.println();

	}

}
