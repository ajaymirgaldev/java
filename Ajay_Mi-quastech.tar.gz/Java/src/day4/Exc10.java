package day4;
public class Exc10 {

	public static void main(String[] args) {
		// 
		// 
		int i, j, n;
		char A;
		//
		i = j = 1; 
		n = 4;
		A = 'A';
		
		//
		for (i = 1; i<=n; i++){
			
			for (j = 1; j<=i; j++){
				System.out.print(A++);
			}
			
			//
			System.out.println();
		}
		System.out.println();
		
		//
		for (i = 1; i<=n; i++){
			A = 'A';
			for (j = 1; j<=i; j++){
				System.out.print(A++);
			}
			
			//
			System.out.println();
		}
		System.out.println();
		
		//
		A = 'A';
		for (i = 1; i<=n; i++){
			
			for (j = 1; j<=i; j++){
				System.out.print(A);
			}
			A++;
			//
			System.out.println();
		}
		System.out.println();
	}

}
