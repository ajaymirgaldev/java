package day4;

import java.util.Scanner;

public class FactorUsingWhileloop {

	public static void main(String[] args) {
		// Factors Using While loop
		
		//Declaration //
		int i, l, f;
		
		//Initialization //
		i = 0;
		f = 1;
		l = 10;
		
		//
		Scanner sc = new Scanner(System.in);

		//
		System.out.println("Please enter int value");
		l = sc.nextInt();
		
		//
		i = 1;
		
		while(i < l){
			
			//
			if(l % i == 0){
				System.out.print(i+", ");
				f = f * i;
			}
			
			//
			i=i+1;
		}
		System.out.println("");
		
		//
		if(f == l){
			System.out.println(l + " is perfect number.");	
		}else{
			System.out.println(l + " is not perfect number.");
		}
		
		//
		sc.close();
	}

}
