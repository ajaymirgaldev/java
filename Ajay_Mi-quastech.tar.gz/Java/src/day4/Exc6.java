package day4;

import java.util.Scanner;

public class Exc6 {

	public static void main(String[] args) {
		// Q. find the Armstrong number//
		//steps
		//1. get the length //
		//pow by length
		//get sum.
		
		//Declaration//
		int n2, n1, n, c, r, s;
		
		//initialization //
		n2 = n1 = n = c = r = s = 0;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please input your number.");	
		n = sc.nextInt();
		
		//
		n1 = n2 = n;
		
		//get length//
		while (n > 0){
			
			//
			n = n / 10;
		
			//
			c++;
		}
		System.out.println("Length "+c);
		
		while (n1 > 0){
			//
			r = n1 % 10;
			//
			s = s + (int) Math.pow(r, c);
			//
			n1 = n1 / 10;
		}
		
		System.out.println("sum "+s);
		//
		if(n2 == s){
			System.out.println(n2 + " is Armstrong number.");	
		}else{
			System.out.println(n2 + " is not Armstrong number.");
		}
		
		sc.close();
	}

}
