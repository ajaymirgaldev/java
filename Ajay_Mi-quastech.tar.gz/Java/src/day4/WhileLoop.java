package day4;

public class WhileLoop {

	public static void main(String[] args) {

		/* -----------While Loop */
		
		//Declaration //
		int i, s, l;
		
		//Initialization //
		i = 0;
		s = 0;
		l = 10;
		
		
		i = 1;
		while (i <= l){
			
			System.out.println(i);
			
			//
			s = s + i;
			
			//
			i = i +1;
		}
		
		System.out.println("Sum "+s);

	}

}
