package day5;

import java.util.Scanner;

public class BinarySearch_Array {

	public static void main(String[] args) {
		/*Declaration*/
		
		int a[] = {1,2,3,4,5,6,7,8,9,10};
		int searchInt, b, e, m;
		//
		Scanner scanner;
		
		/*Implementation*/
		searchInt = b = e = m = 0;
		scanner = new Scanner(System.in);
		
		//
		/*System.out.println("Please input array values");
		for (int i = 0; i < a.length; i++) {
			a[i] = scanner.nextInt();
		}*/
		
		//
		System.out.println("Please input search int bitween 0-10 = ");
		searchInt = scanner.nextInt();
		
		//Start index//
		b = 0;
		
		//end index//
		e = 9;
		
		//Binary Array search//
		System.out.println("begin "+b + " end " + a.length + " searchInt = "+searchInt);
		
		//
		while(b < e){
			m = (b + e)/2;

			System.out.println("m = "+m);
			System.out.println("a[m] = "+a[m]);
			
			if(a[m] == searchInt){
				System.out.println("Search input found! ");				
				break;
			}else if(a[m] < searchInt){
				b = m + 1;
			}else{
				e = m - 1;
			}
		}
		
		//
		scanner.close();
	}

}
