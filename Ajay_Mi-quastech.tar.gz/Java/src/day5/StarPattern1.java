package day5;

import java.util.Scanner;

public class StarPattern1 {

	public static void main(String[] args) {
		/*Declairation*/
		int a;
		Scanner scanner = new Scanner(System.in);
		
		/*Implementaion*/
		a = scanner.nextInt();
		
		
		//
		for(int i = 1; i <= a; i++){
			
			//
			for(int l = a; l > i; l--){
				System.out.print(" ");
			}
			
			//
			for(int j = 1; j <= i; j++){
				System.out.print("*");
			}
			
			//
			for(int k = 1; k <= i; k++){
				System.out.print(k);
			}
			System.out.println();
		}
		
		//close scanner 
		scanner.close();
		
	}

}
