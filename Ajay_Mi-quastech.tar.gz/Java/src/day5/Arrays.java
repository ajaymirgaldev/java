package day5;

import java.util.Scanner;

public class Arrays {

	public static void main(String[] args) {
		/*Declaration*/
		int indexCount, sum, min, max, j, preMax;
		int a[], even[], sort[];
		
		//
		Scanner scanner;

		/*Implementation*/
		indexCount = 10;
		sum = j = preMax = 0;
		a = new int[50];
		even = new int[50];
		sort = new int[50];
		
		//	
		scanner = new Scanner(System.in);
		
		//Storing value to Array through user input //
		 for(int i = 0; i< indexCount; i++){
			 System.out.print("Please input your value for index "+i+" ");
			 
			 //String user input//
			 a[i] = scanner.nextInt();
		 }
		 
		 //String default value to min, max//
		 min = max = a[0];
				 
		 System.out.println();
		 System.out.println("------------------------------ Output");
		 
		 System.out.print("Even numbers: "); 
		
		 //Retrieving value to Array //
		 for(int i = 0; i< indexCount; i++){
			 
			 //Addition //
			 sum =  sum + a[i];
			 
			 /*Min value
			  * Check for previous values is less or grater then 
			  * current index value
			 */ 
			 if(min > a[i]){
				 min = a[i];
			 }
			 
			 /*Max value 
			  * Check for previous values is less or grater then 
			  * current index value
			 */
			 if(max < a[i]){
				 preMax = max;
				 max = a[i];
			 }
			
			 //get even numbers from input array//
			 if(a[i] % 2 == 0){
				System.out.print(a[i]+", ");
				
				//
				even[j] = a[i];
				j++;
				
			}
			 
		 }
		 System.out.println();
		 
		//Sort positive values and negative//
		 int l = 0;
		 for(int i = 0; i< indexCount; i++){
			 if(a[i] >= 0){
				 sort[l] = a[i];
				 l++;
				 System.out.print(a[i]+", ");
			 }
		 }
		 
		 for(int i = 0; i< indexCount; i++){
			 if(a[i] < 0){
				 sort[l] = a[i];
				 l++;
				 System.out.print(a[i]+", ");
			 }
		 }
		 
		 //Printing output //
		 System.out.println();
		 
		 System.out.println("Sum of input "+ sum);
		 System.out.println("Min value entered is "+ min);
		 System.out.println("Max value entered is "+ preMax);
		 System.out.println("Max value entered is "+ max);
		 
		 //
		 scanner.close();
	}

}
