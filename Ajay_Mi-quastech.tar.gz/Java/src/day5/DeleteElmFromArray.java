package day5;

import java.util.Scanner;

public class DeleteElmFromArray {

	public static void main(String[] args) {
		// Delete Element From specific index of Array//
		
		/*Declaration*/
		int a[] = new int[50];
		int orgLength, useInputIndex;
		//
		Scanner scanner;

		/*Implementation*/
		scanner = new Scanner(System.in);
		orgLength = 10;
		
		for (int i = 0; i < orgLength; i++) {
			a[i] = i+1;
			System.out.print(a[i]);
		}
		
		//
		System.out.println();
		
		//
		System.out.println("Please input position number");
		useInputIndex = scanner.nextInt() - 1;
		
		for (int i = useInputIndex; i < orgLength; i++) {
			System.out.println(i);
			a[i] = a[i+1];
		}
		
		//output
		for (int i = 0; i < orgLength-1; i++) {
			System.out.print(a[i]+",");
		}

		
		//
		scanner.close();
	}

}
