package day5;

import java.util.Scanner;

public class InsertElmToArray {

	public static void main(String[] args) {
		// 
		/*Declaration*/
		int a[] = new int[50];
		int orgLength, useInputIndex, useInputValue;
		//
		Scanner scanner;

		/*Implementation*/
		scanner = new Scanner(System.in);
		orgLength = 10;
		
		for (int i = 0; i < orgLength; i++) {
			a[i] = i+1;
			System.out.print(a[i]);
		}
		System.out.println();
		//
		System.out.println("Please input position number");
		useInputIndex = scanner.nextInt() - 1;
		
		//
		System.out.println("Please input index number");
		useInputValue = scanner.nextInt();
		
		//
		for (int i = orgLength-1; i >= useInputIndex; i--) {
			//System.out.println(a[i]);
			System.out.println(a[i]);
			
			//
			//int t = a[i];
			a[i+1] = a[i];
			
			
			/*//
			if(i == useInputIndex){
				System.out.println("Insert value here! "+i);

				a[i] = useInputValue;
				break;
			}
*/		}

		//
		a[useInputIndex] = useInputValue;
		
		//output
		for (int i = 0; i < orgLength+1; i++) {
			System.out.print(a[i]+",");
		}
		
		//
		scanner.close();
	}

}
