package day5;

import java.util.Scanner;

public class TwoD_array {

	public static void main(String[] args) {
		
		/*Declaration*/
		int a[][];
		int rows, cols;
		
		/*Implementation*/
		a = new int[10][10];
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Please input numbers of rows");
		rows = scanner.nextInt();
		
		System.out.println("Please input numbers of colls");
		cols = scanner.nextInt();
		
		//
		for(int i = 0; i < rows; i++){
			for(int j = 0; j < cols-1; j++){
				System.out.println("Please input numbers");
				a[i][j] = scanner.nextInt();
				//System.out.print(j);
			}
			System.out.println("new line");
		}
		System.out.println();
 
		//
		for(int i = 0; i < 1; i++){
			for(int j = 0; j < cols; j++){
				//a[i][j] = scanner.nextInt();
				System.out.print(a[i][j]);
			}
			System.out.println();
		}
		
		//
		for(int i = 0; i < 1; i++){
			for(int j = 0; j < rows; j++){
				System.out.print(a[i][j]);
				
			}
			System.out.println("hello");
		}
		
		//
		scanner.close();
	}
}
