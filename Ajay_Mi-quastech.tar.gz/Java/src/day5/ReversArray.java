package day5;

public class ReversArray {

	public static void main(String[] args) {

		/* Declaration */
		int a[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
		int first;
		
		/* Implementation */
		
		// 
		first = 0;
		
		//
		for(int i=0; i< a.length / 2; i++){
			System.out.println(a[i]);
			
			first = a[i];
			a[i] = a[a.length - i - 1];
			a[a.length - i - 1] = first;
		}
		
		//
		for(int i=0; i< a.length; i++){
			System.out.print(a[i]+",");
		}
	}
}
