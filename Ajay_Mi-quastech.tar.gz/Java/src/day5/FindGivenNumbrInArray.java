package day5;

import java.util.Scanner;

public class FindGivenNumbrInArray {

	public static void main(String[] args) {
		/*Declaration*/
		int a[];
		int searchInput, orgIndex;
		Boolean found;
		
		/*Implementation*/
		a = new int[50];
		found = false;
		orgIndex = 0;
		//
		for(int i = 0; i<10; i++){
			a[i] = i;
		}
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Input your search input between 0 - 9");
		searchInput = scanner.nextInt();
		
		//
		for(int i = 0; i< a.length; i++){
			if(a[i] == searchInput){
				
				found = true;
				orgIndex = i;
				break;
			}
		}
		
		if(found){
			System.out.print("Great! value "+searchInput + " is at index "+orgIndex + " At = "+(orgIndex+1));
		}else{
			System.out.print("Please try again! value "+searchInput + " not found");
		}
		
		//close scanner //
		scanner.close();
	}

}
