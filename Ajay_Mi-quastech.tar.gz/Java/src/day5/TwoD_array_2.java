package day5;

public class TwoD_array_2 {
	public static void main(String[] args) {

		/* Declaration */
		int a[][] = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
		int n;

		/* Implementation */
		n = 0;

		//
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				System.out.print(a[i][j]);
			}
			System.out.println();
		}
		n = a.length;

		//
		System.out.println("------------------------------------------");
		System.out.println();
		//
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				if (i == j) {
					System.out.print(a[i][j]);
				}
			}
			System.out.println();
		}
		System.out.println("------------------------------------------");
		System.out.println();

		//
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				if (i + j == n - 1) {
					System.out.print(a[i][j]);
				}
			}
			System.out.println();
		}
		System.out.println("------------------------------------------");
		System.out.println();

		//
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				if (i >= j) {
					System.out.print(a[i][j]);
				}
			}
			System.out.println();
		}

		System.out.println("------------------------------------------");
		System.out.println();

		//
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				if (i <= j) {
					System.out.print(a[i][j]);
				}
			}
			System.out.println();
		}

	}

}
