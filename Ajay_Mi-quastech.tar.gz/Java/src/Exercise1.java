import java.util.Scanner;


public class Exercise1 {

	public static void main(String[] args) {
		/*
		*Menu
		*1 Accept
		*2 Display
		*3 Search
		*4 Delete
		*5 Sort
		*6 Insertion
		*/
		
		/*Declaration*/
		Scanner scanner;
		int orgLength;
		int a[] = new int[50];
		int userMenuChoice;
		int searchInput, index;
		String y = "y";
		
		/*Implementation*/
		scanner = new Scanner(System.in);
		orgLength = 10;
		userMenuChoice = 0;
		
		//
		do{
			
			System.out.println("Please provide Number values");
			for (int i = 0; i < orgLength-1; i++) {
				a[i] = scanner.nextInt();
			}
			
			//Menu
			System.out.println();
			System.out.println("Menu");
			/*System.out.println("Press 1 to Accept");*/
			System.out.println("Press 1 to Display");
			System.out.println("Press 2 to Search");
			System.out.println("Press 3 to Deletion");
			System.out.println("Press 4 to Insertion");
		
			userMenuChoice = scanner.nextInt();
			
			switch(userMenuChoice){
			case 1:
				System.out.println("You have selected Display the Array");
				break;
				
			case 2:
				System.out.println("You have selected Search in Array");
				System.out.println("Now, please provide search input");
				
				searchInput = scanner.nextInt();
				for (int i = 0; i < orgLength; i++) {
					if(a[i] == searchInput){
						System.out.println(searchInput +" is at index "+(i+1));
					}
				}
				break;
				
			case 3:
				System.out.println("You have selected Deletion in Array");
				System.out.println("Now, please provide Deletion input");
				
				//
				searchInput = scanner.nextInt();
				for (int i = 0; i < orgLength; i++) {
					if(a[i] == searchInput){
						a[i] = a[i+1];
					}
				}
				break;
				
			case 4:
				System.out.println("You have selected Insertion in Array");
				System.out.println("Now, please provide Insertion input.. index and value");
				
				index = scanner.nextInt()-1;
				searchInput = scanner.nextInt();
				for (int i = orgLength-1; i >= index; i--) {
					
					//
					a[i+1] = a[i];
				}
				a[index] = searchInput;
				break;
				
			case 5:	System.exit(0);
			
			deault: System.out.println("Wrong input");
			
			}
			
			//output
			for (int i = 0; i < orgLength; i++) {
				System.out.print(a[i]+",");
			}
			System.out.println();
			
			//
			System.out.println("Do you want to Continue ... y/n");
			y = scanner.next();
			
		} while(y.toLowerCase() != "n");
		
		//
		scanner.close();
	}

}
