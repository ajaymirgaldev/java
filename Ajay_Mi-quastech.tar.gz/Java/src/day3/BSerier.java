package day3;

import java.util.Scanner;

public class BSerier {

	public static void main(String[] args) {
		// 
		Scanner sc = new Scanner(System.in);
		
		// Declarations
		int i, a, b, c, num;
		
		//Initialization
		i = 1;
		a = 0;
		b = 1;
		c = 0;
		
		//
		System.out.println("Prime Numbers ------------------------------");
		
		System.out.println("Enter input number");
		num = sc.nextInt();
		
		
		for(i = 2; i < num; i++){
			System.out.println("a "+a + ", b "+b + ", c "+ c);
			c = a + b;
			
			//
			a = b;
			b = c;
			
			//
			System.out.println("= "+c);
			System.out.println("-----------");
		}
		
		
		//
		sc.close();

	}

}
