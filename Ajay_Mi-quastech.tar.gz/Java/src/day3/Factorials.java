package day3;

import java.util.Scanner;

public class Factorials {

	public static void main(String[] args) {
		//
		Scanner sc = new Scanner(System.in);
		
		// 
		int i, count, a, b, sum, f;
		
		//loop //
		//For//
		i = 1;
		a = 0;
		b = 0;
		count = 10;
		sum = 0;
		f = 1;
		
		System.out.println("Please input number");
		a = sc.nextInt();
		
		System.out.println("factorials ------------------------------");
		
		for(i = 1; i <= count; i++){
			
			b = a % i;
			if(b == 0){
				System.out.println(i);
			}
			
		}
		
		System.out.println("factors ------------------------------");
		for(i = 1; i <= a; i++){
			f = f * i;
			//System.out.println(f);
			sum = sum + f;
		}
		
		System.out.println("factors sum------------------------------ "+sum);
		//
		sc.close();

	}

}
