package day3;

public class Evennumbers {

	public static void main(String[] args) {
		// Odd Numbers
		
				// Declarations
				int i, length, sum;
				
				//Initialization
				i = 0;
				length = 10;
				sum = 0;
				
				//
				System.out.println("Even Numbers -----------------------------");
				
				/*System.out.println("Enter input number");
				length = sc.nextInt();*/
				
				/*for(i = 1; i <= length; i++){
					//System.out.println(i % 2 + " "+ i);
					if(i % 2 == 0){
						System.out.println(i);
						c =  c + i;
					}
					System.out.println(i);
					System.out.println(i);
					
				}*/
				
				for(i = 1; i <= length; i=i+2){
					System.out.println(i);
					sum = sum + i;
				}
				
				System.out.println("-------");
				System.out.println(sum);

	}

}
