package day3;

import java.util.Scanner;

public class JavaLoop {

	public static void main(String[] args) {
		//
		Scanner sc = new Scanner(System.in);
		
		// 
		int i, count, a;
		
		//loop //
		//For//
		i = 1;
		count = 10;
		
		System.out.println("Please input number");
		a = sc.nextInt();
		
		for(i = 1; i <= count; i++){
			
			//System.out.println( " Hello "+ (i * i));
			System.out.println( a+" * "+i +" = "+ (a * i));
			
			//total = total + i;
		}
		
		//System.out.println( " total = "+total);
		
		//
		sc.close();
	}

}
