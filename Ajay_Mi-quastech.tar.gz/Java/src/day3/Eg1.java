package day3;

import java.util.Scanner;

public class Eg1 {
	
	
	public static void main(String[] args) {
		System.out.println("Run eg1");
		
		
		//Get leaf year//
		double a;
		Scanner sc = new Scanner(System.in);
		
		//
		System.out.println("Please enter teh Year ");
		a = sc.nextInt();
		
		if(a % 4 == 0){
			
			if(a % 100 == 0){
				if(a % 400 == 0){
					System.out.println(a + " is century leaf year");
				}
				else{
					System.out.println(a + " is not century leaf year");
				}
			}else{
				System.out.println(a + " is normal leaf year");
			}
		}else {
			System.out.println(a + " is not leaf year");
		}
		
		//
		sc.close();
	}
}
