package day3;

import java.util.Scanner;

public class PrimeNumbers {

	public static void main(String[] args) {
		// 
		Scanner sc = new Scanner(System.in);
		
		// Declarations
		int i, a, factCount;
		
		//Initialization
		i = 1;
		a = 0;
		factCount = 0;
		
		//
		System.out.println("Prime Numbers ------------------------------");
		
		System.out.println("Enter input number");
		a = sc.nextInt();
		
		//Logic 1 --------------------------------------------------- 
		/*for(i = 1; i <= a; i++){
			
			b = a % i;
			if(b == 0){
				factCount++;
			}
			
		}*/
		
		//Logic 2 --------------------------------------------------- 
		for(i = 2; i < (a/2); i++){
			System.out.println(i);
			if(a % i == 0){
				factCount++;
				break;
			}
			
		}
		
		//
		if(factCount == 0){
			System.out.println(a + " a Prime Number");
		}else{
			System.out.println(a + " is not a Prime Number");
		}
		
		//
		sc.close();
	}

}
