package day3;

import java.util.Scanner;

public class SwitchCase2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		char uInput;
		
		System.out.println("Please input char:");
		uInput = sc.next().charAt(0);
		
		//
		switch(uInput){
			
			//
			case 'a':
			case 'A':
			//
			case 'e':
			case 'E':
			
			
			//
			case 'i': 
			case 'I':
			
			//
			case 'o': 
			case 'O': 
			
			//
			case 'u':
			case 'U':	System.out.println(uInput + " Valid Ovel input");
			break;
			
			
			default: System.out.println(uInput + " Invalid Ovel input");
		}
		
		//
		sc.close();
	}

}
