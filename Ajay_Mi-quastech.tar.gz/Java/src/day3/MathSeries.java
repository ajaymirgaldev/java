package day3;

import java.util.Scanner;

public class MathSeries {

	public static void main(String[] args) {
		//
		Scanner sc = new Scanner(System.in);
		
		// 
		int i, length, a, sum;
		
		//
		i = 1;
		a = 0;
		length = 10;
		sum = 0;
		
		System.out.println("Series ------------------------------");
		
		System.out.println("Please input number");
		a = sc.nextInt();
		


		for(i = 1; i <= length; i++){
			System.out.println(a/i);
			sum = sum + (a/i);
		}
		
		System.out.println("Series sum "+sum);

		
		//
		sc.close();
	}

}
