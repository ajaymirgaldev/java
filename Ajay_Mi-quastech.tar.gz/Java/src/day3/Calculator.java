package day3;

import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		// 
		int a, b, c;
		
		//
		Scanner sc = new Scanner(System.in);
		
		System.out.println("To input Symbol + use 1");
		System.out.println("To input Symbol - use 2");
		System.out.println("To input Symbol * use 3");
		System.out.println("To input Symbol / use 4");
		
		System.out.println("Please input Symbol number");
		c = sc.nextInt();
		
		if(c < 1 || c > 4){
			System.out.println( " Invalid Symbol input, programme exit");
			System.exit(0);	
		}
		
		//
		System.out.println("Please input first number");
		a = sc.nextInt();
		
		//
		System.out.println("Please input second number");
		b = sc.nextInt();
		
		//
		switch(c){
		
			//
			case 1: System.out.println((a +" + "+b)+" Answer "+ (a + b));
				break;
			//
			case 2:System.out.println((a +" - "+b)+" Answer "+ (a - b));
				break;
			
			//
			case 3: System.out.println((a +" * "+b)+" Answer "+ (a * b));
				break;
			
			//
			case 4: System.out.println((a +" / "+b)+" Answer "+ (a / b));
				break; 
			
			
			default: System.out.println( " Invalid Symbol input");
		}
		
		//
		sc.close();
	}

}
