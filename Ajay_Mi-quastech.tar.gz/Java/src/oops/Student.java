/**
 * @author Ajay Mirgal
 *
 */
package oops;

import java.util.Scanner;

//Class
class Student{
	
	/*Declaration*/
	String studentName;
	int studentRollNumber;

	/*Implementation*/

	Scanner scanner = new Scanner(System.in);
	//Constructor//
	Student(){}
	
	
	//Get User data Methods//
	public void setStudentInfo(){
		
		//
		System.out.println("Please input your Name");
		scanner.nextLine();
		studentName = scanner.nextLine();
		
		//
		System.out.println("Please input your Roll Number");
		studentRollNumber = scanner.nextInt();
	}
	
	//
	public void getStudentInfo(){
		System.out.println("Student Name "+studentName);
		System.out.println("Student Roll Number "+studentRollNumber);
	}
	
	
	
	//
	public static void main(String[] args){
		
		//Student instance 1
		Student student1 = new Student();
		
		//set student info
		student1.setStudentInfo();
		
		//set student info
		student1.setStudentInfo();
		
		//Student instance 2
		Student student2 = new Student();
		
		//set student info
		student2.setStudentInfo();
		
		//set student info
		student2.setStudentInfo();
		
	}
}