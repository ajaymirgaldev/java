/**
 * 
 */
/**
 * @author student
 *
 */
package j_static;