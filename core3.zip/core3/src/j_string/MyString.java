/**
 * 
 */
package j_string;

import java.util.Scanner;

/**
 * @author student
 *
 */
public class MyString {

	/**
	 * @param args
	 */
	private String myString = "Hello";
	
	
	public static void main(String[] args) {
		
		//
		String s = "Welcome";
		Scanner sc = new Scanner(System.in);
		String email = "";
		
		
		//
		System.out.println(s);
		
		//String concat " to the" //
		s = s.concat(" to the");
		System.out.println("\nString concat: ");
		System.out.println(s);
		
		//concat "JAVA world"
		String s1;
		System.out.println("\nString concat: ");
		s1 = s.concat(" JAVA world");
		System.out.println(s1);
		
		//
		s = s1;
		
		//using toLowerCase method //
		System.out.println("\nString toLowerCase: ");
		s1 = s1.toLowerCase();
		System.out.println(s1);

		//using String length method //
		System.out.println("\nString length: ");
		int n = s.length();
		System.out.println("Chars length = "+n);
		
		//using toUpperCase method //
		System.out.println("\nString toUpperCase: ");
		s1 = s1.toUpperCase();
		System.out.println(s1);
		
		//using substring method with start index //
		System.out.println("\nsubstring method with start index: ");
		s1 = s1.substring(10);
		System.out.println(s1);
		
		//using substring method with start and end index //
		System.out.println("\nsubstring method with start index: ");
		s1 = s1.substring(5, 15);
		System.out.println(s1);
		
		//
		s1 = s;
		
		//using charAt method with index position; return char var //
		System.out.println("\nusing charAt method with index position");
		n = s1.charAt(0);
		System.out.println(n);
		
		//using charAt method with index position; return char var //
		System.out.println("\nusing toCharArray method");
		char a[] = s1.toCharArray();
		System.out.println(a);
		
		//using compareTo method // result will be 0 is matched//
		String s2 = "Hello";
		System.out.println("compareTo return value : "+s2.compareTo("Hello"));
		
		//using contains method // result will be true/false//
		boolean flag = s2.contains("Hello");
		System.out.println("contains return value : "+flag);
		System.out.println("");
		
		//
		System.out.println("Please input your email id:");
		email = sc.next();
		
		//
		char email_array[];
		
		//
		email_array = email.toCharArray();
		//System.out.println(email_array);
		int specialCharsCount = 0; 
		int upperCharsCount = 0;
		int lowerCharsCount = 0;
		int intCharsCount = 0; 
		
		//
		for (int i = 0; i < email_array.length; i++) {
			
			//
			if(email_array[i] >= 'A' && email_array[i] <= 'Z'){
				upperCharsCount++;
			}else if(email_array[i] >= 'a' && email_array[i] <= 'z'){
				lowerCharsCount++;
			}else if(email_array[i] >= '0' && email_array[i] <= '9')
				intCharsCount++;
			else{
				specialCharsCount++;
			}
		}
		
		System.out.println("There are "+upperCharsCount+" uppercase Chars");
		System.out.println("There are "+lowerCharsCount+" lower Chars, ");
		System.out.println("There are "+intCharsCount+" Int Chars, ");
		System.out.println("There are "+specialCharsCount+" Special Chars, ");
		System.out.println("");
		
		//split String
		System.out.println();
		System.out.println("String Split -----------------"); 
		String s3 = "Aaa Abb accc Addd";
		String s4[] = s3.split(" ");
		//System.out.println(s4.length); 
		
		//
		for (int i = 0; i < s4.length; i++) {
			String t = s4[i]; 
			
			//
			char t2 = t.charAt(0);
			
			if(t2 == 'A'){
				System.out.println(t);
			}
		}
		
		// String forEach Array//
		System.out.println();
		System.out.println("String forEach -----------------"); 
		String s12 = new String("We are here");
		s4 = s12.split(" ");
		
		for(String s13 : s4){
			System.out.println(s13);
		}
		
		System.out.println(); 
		
		// String join//
		System.out.println();
		System.out.println("String join -----------------"); 
		String s11 = new String("Hello");
		String s14 = s11.join("@", s3);
		System.out.println(s14);
		System.out.println();
	}

}
