/**
 * 
 */
package j_abstract;

/**
 * @author student
 *
 */
public abstract class HelloAbstract {
	//
	public String hello = "Welcome to JAVA Abstract world";
	
	//
	public void hello(){
		System.out.println("Hello abstract");
	}
	
	//abstract method
	abstract String welcomeToAbstraction();

}
