/**
 * 
 */
package j_hybridinharitance;

/**
 * @author student
 *
 */
public class School implements IAdmin, ILibrary {
	
	//
	public void welcome(){
		System.out.println("Welcome to the school ICS.");
	}
	
	//
	public String studentName(){
		//
		return s_name;
	}
	
	//
	public String studentsurname(){
		//
		return s_surname;
	}
	
	//
	public double studentRollnumber(){
		//
		return rollnumber;
	}
	
	//
	public String books(){
		//
		return myBook;
	}
	
	//
	public double fees(){
		//
		return rsfees;
	}
	
	//
	public String codeOfConduct(){
		//
		return cod;
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		School school = new School();
		school.welcome();
		
		//
		System.out.println(school.studentName());
		System.out.println(school.studentsurname());
		System.out.println(school.studentRollnumber());
		
		//
		System.out.println(school.books());
		
		//
		System.out.println(school.fees());
		System.out.println(school.codeOfConduct());
	}

}
