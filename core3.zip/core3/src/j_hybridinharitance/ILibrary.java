/**
 * 
 */
package j_hybridinharitance;

/**
 * @author student
 *
 */
public interface ILibrary extends IStudent {
	String myBook = "Wings of Fire";
	
	//
	public String books();
}
