/**
 * 
 */
package j_innerclass;

/**
 * @author student
 *
*/

//
public class AnonymousInnerClass {

	/**
	 * @param args
	 */
	
	//
	int b = 0;
	
	//
	void addition(int a, int b){
		System.out.println(" a + b "+(a+b));
	}
	
	//
	Iinterface iInterface = new Iinterface(){
		public double getvalue(){
			return 111;
		}
	};
	
	public static void main(String[] args) {
		
		//
		AnonymousInnerClass aic = new AnonymousInnerClass();
		
		//
		System.out.println(aic.iInterface.getvalue());;
	}

}
