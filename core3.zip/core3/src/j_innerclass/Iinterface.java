/**
 * 
 */
package j_innerclass;

/**
 * @author student
 *
 */

//
public interface Iinterface {
	
	//
	double a = 8;
	//
	public double getvalue();
}
